/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prueba_clases;

/**
 *
 * @author user
 */
public class Estadio {
    private String N_estadio;
    private Double capacidad;
    private String t_deporte;

    public Estadio() {
    }
    
    
    public Estadio(String e, Double c, String d) {
        setN_estadio(e);
        setCapacidad(c);
        setT_deporte(d);
    }

    
    public String getN_estadio() {
        return N_estadio;
    }

    public void setN_estadio(String N_estadio) {
        this.N_estadio = N_estadio;
    }

    public Double getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Double capacidad) {
        this.capacidad = capacidad;
    }

    public String getT_deporte() {
        return t_deporte;
    }

    public void setT_deporte(String t_deporte) {
        this.t_deporte = t_deporte;
    }
    
                    
}
