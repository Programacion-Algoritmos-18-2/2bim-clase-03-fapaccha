/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prueba_clases;

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        LeerArchivoTexto1 leer = new  LeerArchivoTexto1();
        OperacionData o = new OperacionData();
        leer.abrirArchivo();
        o.agregarInformacion(leer.leerRegistros());
        System.out.println("El promedio es "+ o.PromedioCapacidad());
        leer.leerRegistros();

    }
   
}
