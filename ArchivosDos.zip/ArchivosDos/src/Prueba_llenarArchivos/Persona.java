/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prueba_llenarArchivos;

/**
 *
 * @author user
 */
public class Persona {
    private String Nombre;
    private int edad;
    
    public Persona() 
   {
      this("",0); 
   } 
    public Persona(String n , int e){
        setNombre(n);
        setEdad(e);
        
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    
    
    
}
